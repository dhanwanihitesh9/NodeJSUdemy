const location = require('./utils/geocode.js')
const weather = require('./utils/forecast.js')
const yargs = require('yargs')
const address = process.argv[2]

//customize yargs version
yargs.version('1.1.0')

//creay add command
yargs.command({
    command: 'forecast',
    describe: 'Comand to forecast current weather details of a location',
    builder:{
        location: {
            describe: 'Location Name',
            demandOption: true,
            type: 'string'
        }
    },
    handler(argv){
      location.geocode(argv.location,(error, {latitude, longitude}) => {
        if(error)
          console.log(error)
        else{
          weather.forecast(longitude, latitude, (error2, data2) => {
            if(error2)
              console.log(error2)
            else
                console.log(data2)
        })
        }
    })
    }
})

yargs.parse()
