
const console = require('console')
console.log('test')